export default function NewsPage() {
  return (
    <table width="100%" border={0} cellPadding={20} cellSpacing={0}>
      <tbody>
        <tr>
          <td>
            <font size="6" color="#CC0000">
              <b>Новости компании</b>
            </font>
            <hr color="#CC0000" size="3" />
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={15} cellSpacing={0} bgcolor="#FFFFFF">
              <tbody>
                <tr>
                  <td>
                    <font size="4" color="#CC0000"><b>Новое поступление запчастей для BMW</b></font>
                    <br />
                    <font size="2" color="#666666">31 октября 2025</font>
                    <hr color="#EEEEEE" />
                    <font size="3">
                      В наличии появились оригинальные запчасти для автомобилей BMW всех серий. 
                      Двигатели, подвеска, тормозная система, электрика - все в наличии на складе. 
                      Специальные цены для постоянных клиентов и автосервисов. Успейте купить 
                      со скидкой до 20%!
                    </font>
                    <br /><br />
                    <table 
                      border={0}
                      style={{ display: 'inline-block', transition: 'transform 0.3s ease', cursor: 'pointer' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <tbody>
                        <tr>
                          <td bgcolor="#CC0000">
                            <font color="white" size="2"><b>&nbsp;&nbsp;Подробнее&nbsp;&nbsp;</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={15} cellSpacing={0} bgcolor="#FFFFFF">
              <tbody>
                <tr>
                  <td>
                    <font size="4" color="#CC0000"><b>Акция: Скидки на масляные фильтры</b></font>
                    <br />
                    <font size="2" color="#666666">28 октября 2025</font>
                    <hr color="#EEEEEE" />
                    <font size="3">
                      С 28 октября по 10 ноября действует специальная акция на масляные фильтры 
                      для всех марок автомобилей. Скидка до 30% на популярные бренды: Mann, Bosch, 
                      Mahle. При покупке комплекта из 5 фильтров - дополнительная скидка 5%. 
                      Количество товара ограничено!
                    </font>
                    <br /><br />
                    <table 
                      border={0}
                      style={{ display: 'inline-block', transition: 'transform 0.3s ease', cursor: 'pointer' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <tbody>
                        <tr>
                          <td bgcolor="#CC0000">
                            <font color="white" size="2"><b>&nbsp;&nbsp;Подробнее&nbsp;&nbsp;</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={15} cellSpacing={0} bgcolor="#FFFFFF">
              <tbody>
                <tr>
                  <td>
                    <font size="4" color="#CC0000"><b>Открытие нового филиала</b></font>
                    <br />
                    <font size="2" color="#666666">20 октября 2025</font>
                    <hr color="#EEEEEE" />
                    <font size="3">
                      Рады сообщить об открытии нового филиала нашей компании в Санкт-Петербурге. 
                      Теперь клиенты из Северной столицы могут получить запчасти в день заказа с 
                      нашего склада. Адрес: ул. Промышленная, д. 15. Режим работы: пн-пт 9:00-18:00, 
                      сб 10:00-15:00.
                    </font>
                    <br /><br />
                    <table 
                      border={0}
                      style={{ display: 'inline-block', transition: 'transform 0.3s ease', cursor: 'pointer' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <tbody>
                        <tr>
                          <td bgcolor="#CC0000">
                            <font color="white" size="2"><b>&nbsp;&nbsp;Подробнее&nbsp;&nbsp;</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={15} cellSpacing={0} bgcolor="#FFFFFF">
              <tbody>
                <tr>
                  <td>
                    <font size="4" color="#CC0000"><b>Расширение ассортимента запчастей для грузовиков</b></font>
                    <br />
                    <font size="2" color="#666666">15 октября 2025</font>
                    <hr color="#EEEEEE" />
                    <font size="3">
                      Мы значительно расширили ассортимент запчастей для грузовых автомобилей. 
                      Теперь в наличии более 10 000 наименований для МАЗ, КамАЗ, MAN, Scania, Volvo. 
                      Двигатели, тормозные системы, подвеска, электрооборудование - все для вашего 
                      грузовика по выгодным ценам.
                    </font>
                    <br /><br />
                    <table 
                      border={0}
                      style={{ display: 'inline-block', transition: 'transform 0.3s ease', cursor: 'pointer' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <tbody>
                        <tr>
                          <td bgcolor="#CC0000">
                            <font color="white" size="2"><b>&nbsp;&nbsp;Подробнее&nbsp;&nbsp;</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td align="center">
            <table border={0} cellPadding={5} cellSpacing={0}>
              <tbody>
                <tr>
                  <td 
                    bgcolor="#CCCCCC"
                    style={{ transition: 'transform 0.3s ease', cursor: 'pointer' }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    <font size="3"><b>&nbsp;«&nbsp;</b></font>
                  </td>
                  <td 
                    bgcolor="#CC0000"
                    style={{ transition: 'transform 0.3s ease', cursor: 'pointer' }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    <font color="white" size="3"><b>&nbsp;1&nbsp;</b></font>
                  </td>
                  <td 
                    bgcolor="#CCCCCC"
                    style={{ transition: 'transform 0.3s ease', cursor: 'pointer' }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    <font size="3"><b>&nbsp;2&nbsp;</b></font>
                  </td>
                  <td 
                    bgcolor="#CCCCCC"
                    style={{ transition: 'transform 0.3s ease', cursor: 'pointer' }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    <font size="3"><b>&nbsp;3&nbsp;</b></font>
                  </td>
                  <td 
                    bgcolor="#CCCCCC"
                    style={{ transition: 'transform 0.3s ease', cursor: 'pointer' }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    <font size="3"><b>&nbsp;»&nbsp;</b></font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  );
}
