export default function ProductsPage() {
  return (
    <table width="100%" border={0} cellPadding={20} cellSpacing={0}>
      <tbody>
        <tr>
          <td>
            <font size="6" color="#CC0000">
              <b>Товары и услуги</b>
            </font>
            <hr color="#CC0000" size="3" />
          </td>
        </tr>
        <tr>
          <td>
            <font size="4" color="#CC0000">
              <b>Каталог запчастей</b>
            </font>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={0} cellPadding={10} cellSpacing={10}>
              <tbody>
                <tr>
                  <td width="50%" bgcolor="#F5F5F5" valign="top">
                    <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={10} cellSpacing={0} bgcolor="white">
                      <tbody>
                        <tr>
                          <td align="center">
                            <img 
                              src="https://images.unsplash.com/photo-1758381358962-efc41be53986?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBlbmdpbmUlMjBwYXJ0c3xlbnwxfHx8fDE3NjE4MjMwMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                              width="200"
                              height="150"
                              alt="Двигатель"
                            />
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <font size="4" color="#CC0000"><b>Двигатель и система охлаждения</b></font>
                            <hr color="#EEEEEE" />
                            <font size="3">
                              • Поршневая группа<br />
                              • Коленвалы и распредвалы<br />
                              • Прокладки и сальники<br />
                              • Радиаторы и термостаты<br />
                              • Помпы и вентиляторы
                            </font>
                            <br /><br />
                            <font size="3" color="#CC0000"><b>От 500 руб.</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                  <td width="50%" bgcolor="#F5F5F5" valign="top">
                    <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={10} cellSpacing={0} bgcolor="white">
                      <tbody>
                        <tr>
                          <td align="center">
                            <img 
                              src="https://images.unsplash.com/photo-1727413434026-0f8314c037d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjByZXBhaXIlMjB0b29sc3xlbnwxfHx8fDE3NjE5Mzk1MjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                              width="200"
                              height="150"
                              alt="Подвеска"
                            />
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <font size="4" color="#CC0000"><b>Подвеска и рулевое управление</b></font>
                            <hr color="#EEEEEE" />
                            <font size="3">
                              • Амортизаторы и стойки<br />
                              • Рычаги и шаровые опоры<br />
                              • Рулевые рейки и тяги<br />
                              • Сайлентблоки и втулки<br />
                              • Пружины и стабилизаторы
                            </font>
                            <br /><br />
                            <font size="3" color="#CC0000"><b>От 800 руб.</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#F5F5F5" valign="top">
                    <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={10} cellSpacing={0} bgcolor="white">
                      <tbody>
                        <tr>
                          <td>
                            <font size="4" color="#CC0000"><b>Тормозная система</b></font>
                            <hr color="#EEEEEE" />
                            <font size="3">
                              • Тормозные колодки и диски<br />
                              • Суппорты и цилиндры<br />
                              • Тормозные шланги<br />
                              • Главные тормозные цилиндры<br />
                              • ABS датчики
                            </font>
                            <br /><br />
                            <font size="3" color="#CC0000"><b>От 600 руб.</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                  <td bgcolor="#F5F5F5" valign="top">
                    <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={10} cellSpacing={0} bgcolor="white">
                      <tbody>
                        <tr>
                          <td>
                            <font size="4" color="#CC0000"><b>Электрооборудование</b></font>
                            <hr color="#EEEEEE" />
                            <font size="3">
                              • Аккумуляторы<br />
                              • Генераторы и стартеры<br />
                              • Датчики и реле<br />
                              • Свечи зажигания<br />
                              • Проводка и предохранители
                            </font>
                            <br /><br />
                            <font size="3" color="#CC0000"><b>От 300 руб.</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#F5F5F5" valign="top">
                    <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={10} cellSpacing={0} bgcolor="white">
                      <tbody>
                        <tr>
                          <td>
                            <font size="4" color="#CC0000"><b>Кузовные детали</b></font>
                            <hr color="#EEEEEE" />
                            <font size="3">
                              • Бампера и крылья<br />
                              • Капоты и двери<br />
                              • Оптика (фары, фонари)<br />
                              • Зеркала<br />
                              • Молдинги и решетки
                            </font>
                            <br /><br />
                            <font size="3" color="#CC0000"><b>От 1500 руб.</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                  <td bgcolor="#F5F5F5" valign="top">
                    <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={10} cellSpacing={0} bgcolor="white">
                      <tbody>
                        <tr>
                          <td>
                            <font size="4" color="#CC0000"><b>Расходные материалы</b></font>
                            <hr color="#EEEEEE" />
                            <font size="3">
                              • Масла моторные и трансмиссионные<br />
                              • Масляные и воздушные фильтры<br />
                              • Тормозная и охлаждающая жидкость<br />
                              • Антифризы<br />
                              • Омывающая жидкость
                            </font>
                            <br /><br />
                            <font size="3" color="#CC0000"><b>От 200 руб.</b></font>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <hr color="#CC0000" size="2" />
            <font size="4" color="#CC0000">
              <b>Наши услуги</b>
            </font>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CC0000" cellPadding={15} cellSpacing={0} bgcolor="#FFFFEE">
              <tbody>
                <tr>
                  <td width="25%" align="center">
                    <font size="5" color="#CC0000"><b>✓</b></font>
                  </td>
                  <td>
                    <font size="4" color="#CC0000"><b>Подбор запчастей по VIN</b></font><br />
                    <font size="3">Поможем найти точную деталь для вашего автомобиля</font>
                  </td>
                </tr>
                <tr>
                  <td align="center">
                    <font size="5" color="#CC0000"><b>✓</b></font>
                  </td>
                  <td>
                    <font size="4" color="#CC0000"><b>Консультация специалистов</b></font><br />
                    <font size="3">Бесплатная консультация по подбору и установке запчастей</font>
                  </td>
                </tr>
                <tr>
                  <td align="center">
                    <font size="5" color="#CC0000"><b>✓</b></font>
                  </td>
                  <td>
                    <font size="4" color="#CC0000"><b>Доставка по России</b></font><br />
                    <font size="3">Быстрая доставка в любой регион страны</font>
                  </td>
                </tr>
                <tr>
                  <td align="center">
                    <font size="5" color="#CC0000"><b>✓</b></font>
                  </td>
                  <td>
                    <font size="4" color="#CC0000"><b>Гарантия качества</b></font><br />
                    <font size="3">Все товары сертифицированы и имеют гарантию</font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td bgcolor="#FFEEEE" align="center">
            <br />
            <font size="4">
              <b>Не нашли нужную запчасть?</b>
            </font>
            <br />
            <font size="3">
              Позвоните нам по телефону <b>+7 (495) 123-45-67</b> или оставьте заявку на сайте
            </font>
            <br /><br />
            <table 
              border={0}
              style={{ display: 'inline-block', transition: 'transform 0.3s ease', cursor: 'pointer' }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
            >
              <tbody>
                <tr>
                  <td bgcolor="#CC0000">
                    <font color="white" size="3"><b>&nbsp;&nbsp;Оставить заявку&nbsp;&nbsp;</b></font>
                  </td>
                </tr>
              </tbody>
            </table>
            <br />
          </td>
        </tr>
      </tbody>
    </table>
  );
}
