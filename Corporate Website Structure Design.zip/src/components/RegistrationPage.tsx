import { useState } from 'react';

interface RegistrationPageProps {
  onRegister: (data: any) => void;
}

export default function RegistrationPage({ onRegister }: RegistrationPageProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    gender: 'male',
    carBrand: '',
    services: [] as string[],
    experience: 'beginner',
    comments: '',
    newsletter: false,
    terms: false
  });

  const handleCheckboxChange = (service: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  const handleSubmit = () => {
    if (!formData.fullName || !formData.email || !formData.phone) {
      alert('Пожалуйста, заполните обязательные поля!');
      return;
    }
    onRegister(formData);
  };

  return (
    <table width="100%" border={0} cellPadding={20} cellSpacing={0}>
      <tbody>
        <tr>
          <td>
            <font size="6" color="#CC0000">
              <b>Регистрация на сайте</b>
            </font>
            <hr color="#CC0000" size="3" />
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={20} cellSpacing={0} bgcolor="#F9F9F9">
              <tbody>
                <tr>
                  <td>
                    <font size="4" color="#CC0000"><b>Форма регистрации</b></font>
                    <hr color="#CCCCCC" />
                  </td>
                </tr>
                <tr>
                  <td>
                    <table width="100%" border={0} cellPadding={10} cellSpacing={0}>
                      <tbody>
                        <tr>
                          <td width="200" valign="top">
                            <font size="3"><b>Полное имя: *</b></font>
                          </td>
                          <td>
                            <input
                              type="text"
                              size={50}
                              value={formData.fullName}
                              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                              style={{ padding: '5px' }}
                            />
                          </td>
                        </tr>
                        <tr>
                          <td valign="top">
                            <font size="3"><b>Email: *</b></font>
                          </td>
                          <td>
                            <input
                              type="email"
                              size={50}
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                              style={{ padding: '5px' }}
                            />
                          </td>
                        </tr>
                        <tr>
                          <td valign="top">
                            <font size="3"><b>Телефон: *</b></font>
                          </td>
                          <td>
                            <input
                              type="tel"
                              size={50}
                              value={formData.phone}
                              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                              style={{ padding: '5px' }}
                            />
                          </td>
                        </tr>
                        <tr>
                          <td valign="top">
                            <font size="3"><b>Пол:</b></font>
                          </td>
                          <td>
                            <input
                              type="radio"
                              name="gender"
                              value="male"
                              checked={formData.gender === 'male'}
                              onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                            />
                            <font size="3"> Мужской</font>
                            &nbsp;&nbsp;&nbsp;
                            <input
                              type="radio"
                              name="gender"
                              value="female"
                              checked={formData.gender === 'female'}
                              onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                            />
                            <font size="3"> Женский</font>
                          </td>
                        </tr>
                        <tr>
                          <td valign="top">
                            <font size="3"><b>Марка автомобиля:</b></font>
                          </td>
                          <td>
                            <select
                              value={formData.carBrand}
                              onChange={(e) => setFormData({ ...formData, carBrand: e.target.value })}
                              style={{ padding: '5px', width: '300px' }}
                            >
                              <option value="">Выберите марку</option>
                              <option value="toyota">Toyota</option>
                              <option value="bmw">BMW</option>
                              <option value="mercedes">Mercedes-Benz</option>
                              <option value="volkswagen">Volkswagen</option>
                              <option value="audi">Audi</option>
                              <option value="lada">Lada</option>
                              <option value="kia">Kia</option>
                              <option value="hyundai">Hyundai</option>
                              <option value="mazda">Mazda</option>
                              <option value="honda">Honda</option>
                            </select>
                          </td>
                        </tr>
                        <tr>
                          <td valign="top">
                            <font size="3"><b>Интересующие услуги:</b></font>
                          </td>
                          <td>
                            <input
                              type="checkbox"
                              checked={formData.services.includes('parts')}
                              onChange={() => handleCheckboxChange('parts')}
                            />
                            <font size="3"> Покупка запчастей</font>
                            <br />
                            <input
                              type="checkbox"
                              checked={formData.services.includes('delivery')}
                              onChange={() => handleCheckboxChange('delivery')}
                            />
                            <font size="3"> Доставка</font>
                            <br />
                            <input
                              type="checkbox"
                              checked={formData.services.includes('installation')}
                              onChange={() => handleCheckboxChange('installation')}
                            />
                            <font size="3"> Установка запчастей</font>
                            <br />
                            <input
                              type="checkbox"
                              checked={formData.services.includes('consultation')}
                              onChange={() => handleCheckboxChange('consultation')}
                            />
                            <font size="3"> Консультация специалиста</font>
                          </td>
                        </tr>
                        <tr>
                          <td valign="top">
                            <font size="3"><b>Опыт владения авто:</b></font>
                          </td>
                          <td>
                            <select
                              value={formData.experience}
                              onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                              style={{ padding: '5px', width: '300px' }}
                            >
                              <option value="beginner">Начинающий (менее 1 года)</option>
                              <option value="intermediate">Средний (1-5 лет)</option>
                              <option value="experienced">Опытный (5-10 лет)</option>
                              <option value="expert">Эксперт (более 10 лет)</option>
                            </select>
                          </td>
                        </tr>
                        <tr>
                          <td valign="top">
                            <font size="3"><b>Комментарии:</b></font>
                          </td>
                          <td>
                            <textarea
                              rows={5}
                              cols={48}
                              value={formData.comments}
                              onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
                              style={{ padding: '5px' }}
                            />
                          </td>
                        </tr>
                        <tr>
                          <td colSpan={2}>
                            <hr color="#CCCCCC" />
                          </td>
                        </tr>
                        <tr>
                          <td colSpan={2}>
                            <input
                              type="checkbox"
                              checked={formData.newsletter}
                              onChange={(e) => setFormData({ ...formData, newsletter: e.target.checked })}
                            />
                            <font size="3"> Подписаться на новости и специальные предложения</font>
                          </td>
                        </tr>
                        <tr>
                          <td colSpan={2}>
                            <input
                              type="checkbox"
                              checked={formData.terms}
                              onChange={(e) => setFormData({ ...formData, terms: e.target.checked })}
                            />
                            <font size="3"> Я согласен с условиями использования сайта</font>
                          </td>
                        </tr>
                        <tr>
                          <td colSpan={2} align="center">
                            <br />
                            <table border={0} cellPadding={0} cellSpacing={10}>
                              <tbody>
                                <tr>
                                  <td 
                                    bgcolor="#CC0000"
                                    style={{ transition: 'transform 0.3s ease' }}
                                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                                  >
                                    <button
                                      onClick={handleSubmit}
                                      style={{
                                        background: 'transparent',
                                        border: 'none',
                                        color: 'white',
                                        padding: '10px 30px',
                                        cursor: 'pointer'
                                      }}
                                    >
                                      <font size="4"><b>Зарегистрироваться</b></font>
                                    </button>
                                  </td>
                                  <td 
                                    bgcolor="#666666"
                                    style={{ transition: 'transform 0.3s ease' }}
                                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.15)'}
                                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                                  >
                                    <button
                                      style={{
                                        background: 'transparent',
                                        border: 'none',
                                        color: 'white',
                                        padding: '10px 30px',
                                        cursor: 'pointer'
                                      }}
                                    >
                                      <font size="4"><b>Вход</b></font>
                                    </button>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <font size="2" color="#666666">
              * - обязательные поля для заполнения
            </font>
          </td>
        </tr>
      </tbody>
    </table>
  );
}
