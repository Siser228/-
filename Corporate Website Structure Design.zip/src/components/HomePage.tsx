import { useEffect, useState } from 'react';

export default function HomePage() {
  const [dateTime, setDateTime] = useState('');
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      image: 'https://images.unsplash.com/photo-1759419281419-b04552b2691a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvbW90aXZlJTIwc3BhcmUlMjBwYXJ0c3xlbnwxfHx8fDE3NjE4NDgwMDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      text: 'Широкий ассортимент автозапчастей'
    },
    {
      image: 'https://images.unsplash.com/photo-1548287233-af744a9ba268?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBwYXJ0cyUyMHdhcmVob3VzZXxlbnwxfHx8fDE3NjI1MjE4NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      text: 'Большой склад - быстрая доставка'
    },
    {
      image: 'https://images.unsplash.com/photo-1637640125496-31852f042a60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvJTIwbWVjaGFuaWMlMjB3b3Jrc2hvcHxlbnwxfHx8fDE3NjI1MjE4NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      text: 'Профессиональная установка'
    },
    {
      image: 'https://images.unsplash.com/photo-1760827797819-4361cd5cd353?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBtYWludGVuYW5jZSUyMHNlcnZpY2V8ZW58MXx8fHwxNzYyNDI0ODc5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      text: 'Качественное обслуживание'
    }
  ];

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      };
      setDateTime(now.toLocaleString('ru-RU', options));
    };

    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <table width="100%" border={0} cellPadding={20} cellSpacing={0}>
      <tbody>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CC0000" cellPadding={10} cellSpacing={0}>
              <tbody>
                <tr>
                  <td bgcolor="#FFEEEE" align="center">
                    <font color="#CC0000" size="4">
                      <b>Текущая дата и время: {dateTime}</b>
                    </font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <font size="5" color="#CC0000">
              <b>Добро пожаловать в АвтоЗапчасти Премиум!</b>
            </font>
          </td>
        </tr>
        
        {/* СЛАЙДЕР */}
        <tr>
          <td>
            <div style={{ position: 'relative', width: '100%', maxWidth: '800px', height: '400px', margin: '0 auto', overflow: 'hidden', border: '3px solid #CC0000' }}>
              <div style={{ position: 'relative', width: '100%', height: '100%' }}>
                {slides.map((slide, index) => (
                  <div
                    key={index}
                    style={{
                      position: 'absolute',
                      width: '100%',
                      height: '100%',
                      opacity: currentSlide === index ? 1 : 0,
                      transition: 'opacity 1s ease-in-out'
                    }}
                  >
                    <img 
                      src={slide.image}
                      alt={slide.text}
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                    <div style={{
                      position: 'absolute',
                      bottom: 0,
                      left: 0,
                      right: 0,
                      background: 'rgba(204, 0, 0, 0.8)',
                      color: 'white',
                      padding: '15px',
                      textAlign: 'center'
                    }}>
                      <font size="4"><b>{slide.text}</b></font>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Стрелки */}
              <button
                onClick={prevSlide}
                style={{
                  position: 'absolute',
                  top: '50%',
                  left: '10px',
                  transform: 'translateY(-50%)',
                  background: 'rgba(204, 0, 0, 0.7)',
                  color: 'white',
                  border: 'none',
                  fontSize: '30px',
                  padding: '10px 15px',
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                  zIndex: 10
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(204, 0, 0, 0.9)';
                  e.currentTarget.style.transform = 'translateY(-50%) scale(1.2)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(204, 0, 0, 0.7)';
                  e.currentTarget.style.transform = 'translateY(-50%)';
                }}
              >
                ‹
              </button>
              
              <button
                onClick={nextSlide}
                style={{
                  position: 'absolute',
                  top: '50%',
                  right: '10px',
                  transform: 'translateY(-50%)',
                  background: 'rgba(204, 0, 0, 0.7)',
                  color: 'white',
                  border: 'none',
                  fontSize: '30px',
                  padding: '10px 15px',
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                  zIndex: 10
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(204, 0, 0, 0.9)';
                  e.currentTarget.style.transform = 'translateY(-50%) scale(1.2)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(204, 0, 0, 0.7)';
                  e.currentTarget.style.transform = 'translateY(-50%)';
                }}
              >
                ›
              </button>
              
              {/* Точки навигации */}
              <div style={{
                position: 'absolute',
                bottom: '50px',
                left: '50%',
                transform: 'translateX(-50%)',
                display: 'flex',
                gap: '10px',
                zIndex: 10
              }}>
                {slides.map((_, index) => (
                  <span
                    key={index}
                    onClick={() => goToSlide(index)}
                    style={{
                      width: '15px',
                      height: '15px',
                      borderRadius: '50%',
                      background: currentSlide === index ? 'white' : 'rgba(255, 255, 255, 0.5)',
                      cursor: 'pointer',
                      transition: 'background 0.3s',
                      display: 'inline-block'
                    }}
                  />
                ))}
              </div>
            </div>
          </td>
        </tr>
        
        <tr>
          <td>
            <font size="3">
              Наша компания специализируется на продаже качественных автомобильных запчастей 
              для всех марок и моделей автомобилей. Мы работаем на рынке автозапчастей уже более 
              15 лет и зарекомендовали себя как надежный партнер для автовладельцев и автосервисов.
            </font>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={0} cellPadding={10} cellSpacing={0}>
              <tbody>
                <tr>
                  <td width="33%" bgcolor="#EEEEEE" valign="top">
                    <center>
                      <font size="4" color="#CC0000"><b>Широкий ассортимент</b></font>
                    </center>
                    <hr color="#CC0000" />
                    <font size="3">
                      Более 50 000 наименований запчастей для легковых и грузовых автомобилей. 
                      Оригинальные детали и качественные аналоги от проверенных производителей.
                    </font>
                  </td>
                  <td width="33%" bgcolor="#EEEEEE" valign="top">
                    <center>
                      <font size="4" color="#CC0000"><b>Быстрая доставка</b></font>
                    </center>
                    <hr color="#CC0000" />
                    <font size="3">
                      Доставка по всей России в течение 1-3 дней. Самовывоз со склада в день заказа. 
                      Бесплатная доставка при заказе от 5000 рублей.
                    </font>
                  </td>
                  <td width="33%" bgcolor="#EEEEEE" valign="top">
                    <center>
                      <font size="4" color="#CC0000"><b>Гарантия качества</b></font>
                    </center>
                    <hr color="#CC0000" />
                    <font size="3">
                      Все товары сертифицированы. Гарантия на все запчасти от 6 месяцев до 2 лет. 
                      Возврат и обмен товара в течение 14 дней.
                    </font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <font size="4" color="#CC0000">
              <b>О нашей компании</b>
            </font>
            <hr color="#CC0000" size="2" />
          </td>
        </tr>
        <tr>
          <td>
            <font size="3">
              <b>АвтоЗапчасти Премиум</b> - это команда профессионалов, которые знают все о 
              запчастях для автомобилей. Мы предлагаем:
            </font>
            <ul>
              <li><font size="3">Запчасти для двигателя и трансмиссии</font></li>
              <li><font size="3">Детали подвески и рулевого управления</font></li>
              <li><font size="3">Тормозная система и электрика</font></li>
              <li><font size="3">Кузовные детали и оптика</font></li>
              <li><font size="3">Расходные материалы и аксессуары</font></li>
            </ul>
          </td>
        </tr>
        <tr>
          <td bgcolor="#FFEEEE" align="center">
            <font size="4" color="#CC0000">
              <b>☎ Звоните прямо сейчас: +7 (495) 123-45-67</b>
            </font>
          </td>
        </tr>
      </tbody>
    </table>
  );
}
