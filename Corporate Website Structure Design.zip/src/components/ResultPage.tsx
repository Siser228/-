interface ResultPageProps {
  formData: any;
}

export default function ResultPage({ formData }: ResultPageProps) {
  if (!formData) {
    return (
      <table width="100%" border={0} cellPadding={20} cellSpacing={0}>
        <tbody>
          <tr>
            <td>
              <font size="4">Нет данных для отображения</font>
            </td>
          </tr>
        </tbody>
      </table>
    );
  }

  const getGenderText = (gender: string) => {
    return gender === 'male' ? 'Мужской' : 'Женский';
  };

  const getExperienceText = (experience: string) => {
    const map: { [key: string]: string } = {
      'beginner': 'Начинающий (менее 1 года)',
      'intermediate': 'Средний (1-5 лет)',
      'experienced': 'Опытный (5-10 лет)',
      'expert': 'Эксперт (более 10 лет)'
    };
    return map[experience] || experience;
  };

  const getServicesText = (services: string[]) => {
    const map: { [key: string]: string } = {
      'parts': 'Покупка запчастей',
      'delivery': 'Доставка',
      'installation': 'Установка запчастей',
      'consultation': 'Консультация специалиста'
    };
    return services.map(s => map[s]).join(', ') || 'Не выбрано';
  };

  return (
    <table width="100%" border={0} cellPadding={20} cellSpacing={0}>
      <tbody>
        <tr>
          <td>
            <font size="6" color="#CC0000">
              <b>Регистрация завершена!</b>
            </font>
            <hr color="#CC0000" size="3" />
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={2} bordercolor="#00CC00" cellPadding={20} cellSpacing={0} bgcolor="#F0FFF0">
              <tbody>
                <tr>
                  <td align="center">
                    <font size="5" color="#00AA00">
                      <b>✓ Спасибо за регистрацию!</b>
                    </font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <font size="4" color="#CC0000">
              <b>Ваши данные:</b>
            </font>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CCCCCC" cellPadding={15} cellSpacing={0} bgcolor="#FFFFFF">
              <tbody>
                <tr bgcolor="#F5F5F5">
                  <td width="250">
                    <font size="3"><b>Параметр</b></font>
                  </td>
                  <td>
                    <font size="3"><b>Значение</b></font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Полное имя:</b></font>
                  </td>
                  <td>
                    <font size="3">{formData.fullName}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Email:</b></font>
                  </td>
                  <td>
                    <font size="3">{formData.email}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Телефон:</b></font>
                  </td>
                  <td>
                    <font size="3">{formData.phone}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Пол:</b></font>
                  </td>
                  <td>
                    <font size="3">{getGenderText(formData.gender)}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Марка автомобиля:</b></font>
                  </td>
                  <td>
                    <font size="3">{formData.carBrand || 'Не указано'}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Интересующие услуги:</b></font>
                  </td>
                  <td>
                    <font size="3">{getServicesText(formData.services)}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Опыт владения авто:</b></font>
                  </td>
                  <td>
                    <font size="3">{getExperienceText(formData.experience)}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA" valign="top">
                    <font size="3"><b>Комментарии:</b></font>
                  </td>
                  <td>
                    <font size="3">{formData.comments || 'Не указано'}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Подписка на новости:</b></font>
                  </td>
                  <td>
                    <font size="3">{formData.newsletter ? 'Да' : 'Нет'}</font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#FAFAFA">
                    <font size="3"><b>Согласие с условиями:</b></font>
                  </td>
                  <td>
                    <font size="3">{formData.terms ? 'Да' : 'Нет'}</font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <table width="100%" border={1} bordercolor="#CC0000" cellPadding={15} cellSpacing={0} bgcolor="#FFFFEE">
              <tbody>
                <tr>
                  <td>
                    <font size="3">
                      <b>Что дальше?</b><br /><br />
                      1. На вашу почту отправлено письмо с подтверждением регистрации<br />
                      2. Вы можете начать пользоваться всеми функциями сайта<br />
                      3. При заказе используйте ваш email для входа в личный кабинет<br />
                      4. Следите за специальными предложениями для зарегистрированных пользователей<br />
                    </font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td align="center">
            <br />
            <table border={0} cellPadding={0} cellSpacing={10}>
              <tbody>
                <tr>
                  <td bgcolor="#CC0000">
                    <a 
                      href="#" 
                      onClick={(e) => { e.preventDefault(); window.location.reload(); }}
                      style={{ textDecoration: 'none' }}
                    >
                      <font color="white" size="4"><b>&nbsp;&nbsp;На главную страницу&nbsp;&nbsp;</b></font>
                    </a>
                  </td>
                  <td bgcolor="#666666">
                    <font color="white" size="4"><b>&nbsp;&nbsp;Перейти в каталог&nbsp;&nbsp;</b></font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  );
}
