import { useState } from 'react';
import HomePage from './components/HomePage';
import NewsPage from './components/NewsPage';
import RegistrationPage from './components/RegistrationPage';
import ProductsPage from './components/ProductsPage';
import ResultPage from './components/ResultPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [formData, setFormData] = useState(null);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'news':
        return <NewsPage />;
      case 'registration':
        return <RegistrationPage onRegister={(data) => {
          setFormData(data);
          setCurrentPage('result');
        }} />;
      case 'products':
        return <ProductsPage />;
      case 'result':
        return <ResultPage formData={formData} />;
      default:
        return <HomePage />;
    }
  };

  return (
    <table width="100%" height="100vh" border={0} cellPadding={0} cellSpacing={0}>
      <tbody>
        <tr>
          <td colSpan={2} bgcolor="#CC0000" height="100">
            <table width="100%" border={0} cellPadding={10} cellSpacing={0}>
              <tbody>
                <tr>
                  <td width="200" align="center">
                    <img 
                      src="https://images.unsplash.com/photo-1644004485045-da65391d6f44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvJTIwcGFydHMlMjBsb2dvfGVufDF8fHx8MTc2MTg0NTM4M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      width="80"
                      height="80"
                      alt="Логотип"
                      style={{ transition: 'transform 0.2s ease', cursor: 'pointer' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    />
                  </td>
                  <td>
                    <font color="white" size="6">
                      <b>АвтоЗапчасти Премиум</b>
                    </font>
                    <br />
                    <font color="white" size="3">
                      Ваш надежный партнер
                    </font>
                  </td>
                  <td width="400" align="center">
                    <img 
                      src="https://images.unsplash.com/photo-1758381358962-efc41be53986?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBlbmdpbmUlMjBwYXJ0c3xlbnwxfHx8fDE3NjE4MjMwMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      width="120"
                      height="80"
                      alt="Запчасти"
                      style={{ transition: 'transform 0.2s ease', cursor: 'pointer' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td colSpan={2} bgcolor="#666666" height="40">
            <table width="100%" border={0} cellPadding={8} cellSpacing={0}>
              <tbody>
                <tr>
                  <td width="150" align="center" bgcolor={currentPage === 'home' ? '#555555' : '#666666'}>
                    <a 
                      href="#" 
                      onClick={(e) => { e.preventDefault(); setCurrentPage('home'); }}
                      style={{ color: 'white', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <font color="white" size="3"><b>Главная</b></font>
                    </a>
                  </td>
                  <td width="150" align="center" bgcolor={currentPage === 'news' ? '#555555' : '#666666'}>
                    <a 
                      href="#" 
                      onClick={(e) => { e.preventDefault(); setCurrentPage('news'); }}
                      style={{ color: 'white', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <font color="white" size="3"><b>Новости</b></font>
                    </a>
                  </td>
                  <td width="150" align="center" bgcolor={currentPage === 'registration' ? '#555555' : '#666666'}>
                    <a 
                      href="#" 
                      onClick={(e) => { e.preventDefault(); setCurrentPage('registration'); }}
                      style={{ color: 'white', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <font color="white" size="3"><b>Регистрация</b></font>
                    </a>
                  </td>
                  <td width="150" align="center" bgcolor={currentPage === 'products' ? '#555555' : '#666666'}>
                    <a 
                      href="#" 
                      onClick={(e) => { e.preventDefault(); setCurrentPage('products'); }}
                      style={{ color: 'white', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                    >
                      <font color="white" size="3"><b>Каталог</b></font>
                    </a>
                  </td>
                  <td bgcolor="#666666"></td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td width="200" bgcolor="#999999" valign="top">
            <table width="100%" border={0} cellPadding={10} cellSpacing={0}>
              <tbody>
                <tr>
                  <td bgcolor="#888888">
                    <font color="white" size="4"><b>Меню навигации</b></font>
                  </td>
                </tr>
                <tr>
                  <td>
                    <font size="3">
                      <a 
                        href="#" 
                        onClick={(e) => { e.preventDefault(); setCurrentPage('home'); }}
                        style={{ color: 'black', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                        onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                        onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                      >
                        ► Главная
                      </a>
                    </font>
                  </td>
                </tr>
                <tr>
                  <td>
                    <font size="3">
                      <a 
                        href="#" 
                        onClick={(e) => { e.preventDefault(); setCurrentPage('news'); }}
                        style={{ color: 'black', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                        onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                        onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                      >
                        ► Новости
                      </a>
                    </font>
                  </td>
                </tr>
                <tr>
                  <td>
                    <font size="3">
                      <a 
                        href="#" 
                        onClick={(e) => { e.preventDefault(); setCurrentPage('products'); }}
                        style={{ color: 'black', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                        onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                        onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                      >
                        ► Товары и услуги
                      </a>
                    </font>
                  </td>
                </tr>
                <tr>
                  <td>
                    <font size="3">
                      <a 
                        href="#" 
                        onClick={(e) => { e.preventDefault(); setCurrentPage('registration'); }}
                        style={{ color: 'black', textDecoration: 'none', display: 'inline-block', transition: 'transform 0.2s ease' }}
                        onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                        onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                      >
                        ► Регистрация
                      </a>
                    </font>
                  </td>
                </tr>
                <tr>
                  <td bgcolor="#888888">
                    <font color="white" size="4"><b>Архив новостей</b></font>
                  </td>
                </tr>
                <tr>
                  <td><font size="2">► Октябрь 2025</font></td>
                </tr>
                <tr>
                  <td><font size="2">► Сентябрь 2025</font></td>
                </tr>
                <tr>
                  <td><font size="2">► Август 2025</font></td>
                </tr>
                <tr>
                  <td bgcolor="#888888">
                    <font color="white" size="4"><b>Контакты</b></font>
                  </td>
                </tr>
                <tr>
                  <td>
                    <font size="2">
                      Тел: +7 (495) 123-45-67<br />
                      Email: info@avtozapchasti.ru
                    </font>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
          <td bgcolor="#FFFFFF" valign="top">
            {renderPage()}
          </td>
        </tr>
        <tr>
          <td colSpan={2} bgcolor="#666666" height="50">
            <center>
              <font color="white" size="2">
                © 2025 АвтоЗапчасти Премиум. Все права защищены.
              </font>
            </center>
          </td>
        </tr>
      </tbody>
    </table>
  );
}
